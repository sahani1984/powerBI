export class Apis {
    public static login = "default/lambda-CountifiFunction-oXMgCpV1IaNO"
    public static register = "default/lambda-CountifiFunction-oXMgCpV1IaNO";
    public static signOut = "default/lambda-CountifiFunction-oXMgCpV1IaNO";
    public static userListing = "default/lambda-CountifiFunction-oXMgCpV1IaNO";
    public static clientListing = "default/lambda-CountifiFunction-oXMgCpV1IaNO";
    public static enableuser = "default/lambda-CountifiFunction-oXMgCpV1IaNO";
    public static flightBeverages = "airlines/flights/beverages";
    public static beverages = "airlines/beverages";
    
 }